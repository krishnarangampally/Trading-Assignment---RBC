1. Start TradingPlatform.Api.exe
2. Wait until API shows:
   https://localhost:7049

3. Start TradingPlatform.WinForms.exe

4. Select an account

5. View positions

6. Place orders