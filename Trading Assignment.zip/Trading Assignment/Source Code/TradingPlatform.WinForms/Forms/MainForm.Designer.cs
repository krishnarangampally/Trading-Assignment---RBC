﻿namespace TradingPlatform.WinForms.Forms
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            dgvAccounts = new DataGridView();
            btnRefresh = new Button();
            btnPlaceOrder = new Button();
            dgvPositions = new DataGridView();
            lblCashBalance = new Label();
            lblClientName = new Label();
            lblAccountNumber = new Label();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPositions).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(dgvAccounts);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(btnRefresh);
            splitContainer1.Panel2.Controls.Add(btnPlaceOrder);
            splitContainer1.Panel2.Controls.Add(dgvPositions);
            splitContainer1.Panel2.Controls.Add(lblCashBalance);
            splitContainer1.Panel2.Controls.Add(lblClientName);
            splitContainer1.Panel2.Controls.Add(lblAccountNumber);
            splitContainer1.Size = new Size(1510, 484);
            splitContainer1.SplitterDistance = 501;
            splitContainer1.TabIndex = 0;
            // 
            // dgvAccounts
            // 
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Dock = DockStyle.Fill;
            dgvAccounts.Location = new Point(0, 0);
            dgvAccounts.MultiSelect = false;
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.ReadOnly = true;
            dgvAccounts.RowHeadersWidth = 51;
            dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.Size = new Size(501, 484);
            dgvAccounts.TabIndex = 0;
            dgvAccounts.SelectionChanged += dgvAccounts_SelectionChanged;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(142, 342);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(94, 29);
            btnRefresh.TabIndex = 5;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnPlaceOrder
            // 
            btnPlaceOrder.Location = new Point(22, 342);
            btnPlaceOrder.Name = "btnPlaceOrder";
            btnPlaceOrder.Size = new Size(94, 29);
            btnPlaceOrder.TabIndex = 4;
            btnPlaceOrder.Text = "Place Order";
            btnPlaceOrder.UseVisualStyleBackColor = true;
            btnPlaceOrder.Click += btnPlaceOrder_Click;
            // 
            // dgvPositions
            // 
            dgvPositions.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPositions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPositions.Location = new Point(22, 133);
            dgvPositions.Name = "dgvPositions";
            dgvPositions.ReadOnly = true;
            dgvPositions.RowHeadersWidth = 51;
            dgvPositions.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPositions.Size = new Size(971, 188);
            dgvPositions.TabIndex = 3;
            // 
            // lblCashBalance
            // 
            lblCashBalance.AutoSize = true;
            lblCashBalance.Location = new Point(22, 100);
            lblCashBalance.Name = "lblCashBalance";
            lblCashBalance.Size = new Size(92, 20);
            lblCashBalance.TabIndex = 2;
            lblCashBalance.Text = "CashBalance";
            // 
            // lblClientName
            // 
            lblClientName.AutoSize = true;
            lblClientName.Location = new Point(22, 67);
            lblClientName.Name = "lblClientName";
            lblClientName.Size = new Size(87, 20);
            lblClientName.TabIndex = 1;
            lblClientName.Text = "ClientName";
            // 
            // lblAccountNumber
            // 
            lblAccountNumber.AutoSize = true;
            lblAccountNumber.Location = new Point(22, 33);
            lblAccountNumber.Name = "lblAccountNumber";
            lblAccountNumber.Size = new Size(117, 20);
            lblAccountNumber.TabIndex = 0;
            lblAccountNumber.Text = "AccountNumber";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1510, 484);
            Controls.Add(splitContainer1);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPositions).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private DataGridView dgvAccounts;
        private Label lblAccountNumber;
        private Label lblCashBalance;
        private Label lblClientName;
        private Button btnRefresh;
        private Button btnPlaceOrder;
        private DataGridView dgvPositions;
    }
}
