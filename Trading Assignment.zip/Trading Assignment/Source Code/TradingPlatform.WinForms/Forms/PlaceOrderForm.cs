﻿using TradingPlatform.WinForms.Models;
using TradingPlatform.WinForms.Services;

namespace TradingPlatform.WinForms.Forms;

public partial class PlaceOrderForm : Form
{
    private readonly ApiClient _apiClient =
        new();

    private readonly AccountDto _account;

    public PlaceOrderForm(AccountDto account)
    {
        InitializeComponent();

        _account = account;
    }

    private void PlaceOrderForm_Load(
        object sender,
        EventArgs e)
    {
        lblAccountNumber.Text =
            _account.AccountNumber;

        lblCashBalance.Text =
            _account.CashBalance.ToString("C");

        cmbOrderType.Items.Add("Buy");
        cmbOrderType.Items.Add("Sell");

        cmbOrderType.SelectedIndex = 0;

        cmbSymbol.Items.AddRange(
        [
            "AAPL",
            "MSFT",
            "NVDA"
        ]);

        cmbSymbol.SelectedIndex = 0;
    }

    private async void btnSubmit_Click(object sender, EventArgs e)
    {
        if (numQuantity.Value <= 0)
        {
            MessageBox.Show(
                "Quantity must be greater than zero");

            return;
        }

        if (!decimal.TryParse(
            txtLimitPrice.Text,
            out decimal limitPrice))
        {
            MessageBox.Show(
                "Invalid limit price");

            return;
        }

        if (limitPrice <= 0)
        {
            MessageBox.Show(
                "Limit price must be greater than 0");

            return;
        }

        decimal total =
            limitPrice * numQuantity.Value;

        if (cmbOrderType.Text == "Buy" &&
            total > _account.CashBalance)
        {
            MessageBox.Show(
                "Insufficient cash balance");

            return;
        }

        var request = new OrderRequest
        {
            AccountId = _account.AccountId,
            Symbol = cmbSymbol.Text,
            OrderType = cmbOrderType.Text,
            Quantity = (int)numQuantity.Value,
            LimitPrice = limitPrice
        };

        var response =
            await _apiClient.PlaceOrderAsync(
                request);

        if (response.IsSuccessStatusCode)
        {
            MessageBox.Show(
                "Order submitted successfully");

            DialogResult = DialogResult.OK;

            Close();
        }
        else
        {
            var error =
                await response.Content
                    .ReadAsStringAsync();

            MessageBox.Show(error);
        }
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        Close();
    }
}