﻿namespace TradingPlatform.WinForms.Forms
{
    partial class PlaceOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblAccountNumber = new Label();
            lblCashBalance = new Label();
            cmbSymbol = new ComboBox();
            cmbOrderType = new ComboBox();
            numQuantity = new NumericUpDown();
            txtLimitPrice = new TextBox();
            btnSubmit = new Button();
            btnCancel = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)numQuantity).BeginInit();
            SuspendLayout();
            // 
            // lblAccountNumber
            // 
            lblAccountNumber.AutoSize = true;
            lblAccountNumber.Location = new Point(17, 20);
            lblAccountNumber.Name = "lblAccountNumber";
            lblAccountNumber.Size = new Size(117, 20);
            lblAccountNumber.TabIndex = 0;
            lblAccountNumber.Text = "AccountNumber";
            // 
            // lblCashBalance
            // 
            lblCashBalance.AutoSize = true;
            lblCashBalance.Location = new Point(19, 55);
            lblCashBalance.Name = "lblCashBalance";
            lblCashBalance.Size = new Size(92, 20);
            lblCashBalance.TabIndex = 1;
            lblCashBalance.Text = "CashBalance";
            // 
            // cmbSymbol
            // 
            cmbSymbol.FormattingEnabled = true;
            cmbSymbol.Location = new Point(186, 97);
            cmbSymbol.Name = "cmbSymbol";
            cmbSymbol.Size = new Size(151, 28);
            cmbSymbol.TabIndex = 2;
            // 
            // cmbOrderType
            // 
            cmbOrderType.FormattingEnabled = true;
            cmbOrderType.Location = new Point(186, 140);
            cmbOrderType.Name = "cmbOrderType";
            cmbOrderType.Size = new Size(151, 28);
            cmbOrderType.TabIndex = 3;
            // 
            // numQuantity
            // 
            numQuantity.Location = new Point(188, 189);
            numQuantity.Name = "numQuantity";
            numQuantity.Size = new Size(150, 27);
            numQuantity.TabIndex = 4;
            // 
            // txtLimitPrice
            // 
            txtLimitPrice.Location = new Point(188, 233);
            txtLimitPrice.Name = "txtLimitPrice";
            txtLimitPrice.Size = new Size(150, 27);
            txtLimitPrice.TabIndex = 5;
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(17, 284);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(94, 29);
            btnSubmit.TabIndex = 6;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(126, 284);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 7;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 100);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 8;
            label1.Text = "Symbol";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 148);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 9;
            label2.Text = "Order Type";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 196);
            label3.Name = "label3";
            label3.Size = new Size(65, 20);
            label3.TabIndex = 10;
            label3.Text = "Quantity";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(26, 240);
            label4.Name = "label4";
            label4.Size = new Size(78, 20);
            label4.TabIndex = 11;
            label4.Text = "Limit Price";
            // 
            // PlaceOrderForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(492, 401);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Controls.Add(btnSubmit);
            Controls.Add(txtLimitPrice);
            Controls.Add(numQuantity);
            Controls.Add(cmbOrderType);
            Controls.Add(cmbSymbol);
            Controls.Add(lblCashBalance);
            Controls.Add(lblAccountNumber);
            Name = "PlaceOrderForm";
            Text = "PlaceOrderForm";
            Load += PlaceOrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)numQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAccountNumber;
        private Label lblCashBalance;
        private ComboBox cmbSymbol;
        private ComboBox cmbOrderType;
        private NumericUpDown numQuantity;
        private TextBox txtLimitPrice;
        private Button btnSubmit;
        private Button btnCancel;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}