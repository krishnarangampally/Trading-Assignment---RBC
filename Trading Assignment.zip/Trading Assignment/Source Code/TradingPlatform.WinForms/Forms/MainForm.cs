using TradingPlatform.WinForms.Models;
using TradingPlatform.WinForms.Services;

namespace TradingPlatform.WinForms.Forms;

public partial class MainForm : Form
{
    private readonly ApiClient _apiClient =
        new();

    private AccountDto? _selectedAccount;

    private System.Windows.Forms.Timer _timer =
        new();

    public MainForm()
    {
        InitializeComponent();
    }

    private async void MainForm_Load(
        object sender,
        EventArgs e)
    {
        await LoadAccounts();

        _timer.Interval = 5000;
        _timer.Tick += Timer_Tick;
        _timer.Start();

        btnPlaceOrder.Enabled = false;
    }

    private async void Timer_Tick(
        object? sender,
        EventArgs e)
    {
        if (_selectedAccount != null)
        {
            await LoadPositions(
                _selectedAccount.AccountId);
        }
    }

    private async Task LoadAccounts()
    {
        var accounts =
            await _apiClient.GetAccountsAsync();

        dgvAccounts.DataSource = accounts;
    }

    private async Task LoadPositions(
        int accountId)
    {
        var positions =
            await _apiClient
                .GetPositionsAsync(accountId);

        dgvPositions.DataSource = positions;
    }

    private async void dgvAccounts_SelectionChanged(
        object sender,
        EventArgs e)
    {
        if (dgvAccounts.CurrentRow == null)
            return;

        _selectedAccount =
            dgvAccounts.CurrentRow.DataBoundItem
                as AccountDto;

        if (_selectedAccount == null)
            return;

        lblAccountNumber.Text =
            $"Account: {_selectedAccount.AccountNumber}";

        lblClientName.Text =
            $"Client: {_selectedAccount.ClientName}";

        lblCashBalance.Text =
            $"Cash: {_selectedAccount.CashBalance:C}";

        btnPlaceOrder.Enabled = true;

        await LoadPositions(
            _selectedAccount.AccountId);
    }

    private async void btnRefresh_Click(
        object sender,
        EventArgs e)
    {
        if (_selectedAccount != null)
        {
            await LoadPositions(
                _selectedAccount.AccountId);
        }
    }

    private void btnPlaceOrder_Click(
        object sender,
        EventArgs e)
    {
        if (_selectedAccount == null)
            return;

        using var form =
            new PlaceOrderForm(_selectedAccount);

        form.ShowDialog();
    }
}