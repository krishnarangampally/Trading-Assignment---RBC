﻿namespace TradingPlatform.WinForms.Models;

public class AccountDto
{
    public int AccountId { get; set; }

    public string AccountNumber { get; set; }

    public string ClientName { get; set; }

    public decimal CashBalance { get; set; }
}