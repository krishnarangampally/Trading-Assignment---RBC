﻿namespace TradingPlatform.WinForms.Models;

public class OrderRequest
{
    public int AccountId { get; set; }

    public string Symbol { get; set; }

    public string OrderType { get; set; }

    public int Quantity { get; set; }

    public decimal LimitPrice { get; set; }
}