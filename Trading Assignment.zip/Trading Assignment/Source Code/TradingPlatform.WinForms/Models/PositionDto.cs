﻿namespace TradingPlatform.WinForms.Models;

public class PositionDto
{
    public int PositionId { get; set; }

    public string Symbol { get; set; }

    public int Quantity { get; set; }

    public decimal AverageCostPerShare { get; set; }

    public decimal CurrentPrice { get; set; }

    public decimal CurrentValue { get; set; }
}