﻿using System.Net.Http.Json;
using TradingPlatform.WinForms.Models;

namespace TradingPlatform.WinForms.Services;

public class ApiClient
{
    private readonly HttpClient _httpClient;

    public ApiClient()
    {
        _httpClient = new HttpClient();
        _httpClient.BaseAddress =
            new Uri("https://localhost:7049/");
    }

    public async Task<List<AccountDto>> GetAccountsAsync()
    {
        return await _httpClient
            .GetFromJsonAsync<List<AccountDto>>(
                "api/accounts");
    }

    public async Task<List<PositionDto>>
        GetPositionsAsync(int accountId)
    {
        return await _httpClient
            .GetFromJsonAsync<List<PositionDto>>(
                $"api/positions/account/{accountId}");
    }

    public async Task<HttpResponseMessage>
        PlaceOrderAsync(OrderRequest request)
    {
        return await _httpClient
            .PostAsJsonAsync("api/orders", request);
    }
}