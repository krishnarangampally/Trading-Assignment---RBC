﻿using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Services;

public class TradingDataService
{
    public List<Account> Accounts { get; } = new()
    {
        new Account
        {
            AccountId = 1,
            AccountNumber = "ACC1001",
            ClientName = "John Smith",
            CashBalance = 50000
        },
        new Account
        {
            AccountId = 2,
            AccountNumber = "ACC1002",
            ClientName = "Sarah Jones",
            CashBalance = 80000
        }
    };

    public List<Equity> Equities { get; } = new()
    {
        new Equity { EquityId = 1, Symbol = "AAPL", CurrentPrice = 210 },
        new Equity { EquityId = 2, Symbol = "MSFT", CurrentPrice = 450 },
        new Equity { EquityId = 3, Symbol = "NVDA", CurrentPrice = 150 }
    };

    public List<Position> Positions { get; } = new()
    {
        new Position
        {
            PositionId = 1,
            AccountId = 1,
            EquityId = 1,
            Symbol = "AAPL",
            Quantity = 100,
            AverageCostPerShare = 180
        },
        new Position
        {
            PositionId = 2,
            AccountId = 1,
            EquityId = 2,
            Symbol = "MSFT",
            Quantity = 50,
            AverageCostPerShare = 390
        }
    };
}
