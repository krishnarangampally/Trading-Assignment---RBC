using TradingPlatform.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<TradingDataService>();

builder.WebHost.UseUrls(
    "https://localhost:7049",
    "http://localhost:5210");

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors();

app.MapControllers();

app.Run();