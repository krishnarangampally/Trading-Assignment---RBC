﻿using Microsoft.AspNetCore.Mvc;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/positions")]
public class PositionsController : ControllerBase
{
    private readonly TradingDataService _service;

    public PositionsController(TradingDataService service)
    {
        _service = service;
    }

    [HttpGet("account/{accountId}")]
    public IActionResult Get(int accountId)
    {
        var result = _service.Positions
            .Where(x => x.AccountId == accountId)
            .Select(x =>
            {
                var equity = _service.Equities
                    .First(e => e.EquityId == x.EquityId);

                return new
                {
                    x.PositionId,
                    x.Symbol,
                    x.Quantity,
                    x.AverageCostPerShare,
                    equity.CurrentPrice, // Simplified member name
                    CurrentValue = equity.CurrentPrice * x.Quantity
                };
            });

        return Ok(result);
    }
}