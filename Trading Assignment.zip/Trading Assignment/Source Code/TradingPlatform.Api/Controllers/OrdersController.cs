﻿using Microsoft.AspNetCore.Mvc;
using TradingPlatform.Api.Models;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    private readonly TradingDataService _service;

    public OrdersController(TradingDataService service)
    {
        _service = service;
    }

    [HttpPost]
    public async Task<IActionResult> PlaceOrder(
        OrderRequest request)
    {
        var account = _service.Accounts
            .FirstOrDefault(a =>
                a.AccountId == request.AccountId);

        if (account == null)
            return BadRequest("Account not found");

        var cost =
            request.Quantity * request.LimitPrice;

        if (request.OrderType == "Buy" &&
            account.CashBalance < cost)
        {
            return BadRequest(
                "Insufficient funds");
        }

        _ = Task.Run(async () =>
        {
            await Task.Delay(5000);

            var equity = _service.Equities
                .First(x => x.Symbol == request.Symbol);

            var position =
                _service.Positions.FirstOrDefault(x =>
                    x.AccountId == request.AccountId &&
                    x.Symbol == request.Symbol);

            if (position == null)
            {
                _service.Positions.Add(new Position
                {
                    PositionId =
                        _service.Positions.Count + 1,
                    AccountId = request.AccountId,
                    EquityId = equity.EquityId,
                    Symbol = equity.Symbol,
                    Quantity = request.Quantity,
                    AverageCostPerShare =
                        request.LimitPrice
                });
            }
            else
            {
                position.Quantity += request.Quantity;
            }

            account.CashBalance -= cost;
        });

        return Ok("Order Accepted");
    }
}