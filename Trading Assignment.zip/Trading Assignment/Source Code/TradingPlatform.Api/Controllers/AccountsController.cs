using Microsoft.AspNetCore.Mvc;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/accounts")]
public class AccountsController : ControllerBase
{
    private readonly TradingDataService _service;

    public AccountsController(TradingDataService service)
    {
        _service = service;
    }

    [HttpGet]
    public IActionResult Get()
    {
        return Ok(_service.Accounts);
    }
}